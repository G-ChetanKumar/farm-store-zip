const express = require("express");
const router = express.Router();
const auth = require("../middlewares/Auth");
const adminAuth = require("../middlewares/AdminAuth");
const paymentController = require("../controllers/PaymentController");

router.post("/create-order", auth, paymentController.createSimpleOrder);
router.post("/create-gateway-order", auth, paymentController.createGatewayOrder);
router.post("/webhook", paymentController.verifyWebhook);
router.get("/get-payments", adminAuth, paymentController.getPayments);
router.get("/payment-stats", adminAuth, paymentController.getPaymentStats);
router.post("/process-refund/:id", adminAuth, paymentController.processRefund);

module.exports = router;
