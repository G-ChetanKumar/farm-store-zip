const Cart = require("../models/CartModel");
const { sanitizeString } = require("../lib/validation");

const sanitizeNumber = (value) => {
  if (value === null || value === undefined || value === "") return undefined;
  const num = Number(value);
  return Number.isNaN(num) ? undefined : num;
};

const isValidObjectId = (value) =>
  typeof value === "string" && /^[a-fA-F0-9]{24}$/.test(value);

exports.getCart = async (req, res) => {
  try {
    const cart = await Cart.findOne({ user_id: req.user });
    res.status(200).json({ success: true, data: cart || { user_id: req.user, items: [] } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.setCart = async (req, res) => {
  try {
    const items = Array.isArray(req.body.items) ? req.body.items : [];
    const normalizedItems = items.map((item) => ({
      product_id: sanitizeString(item.product_id),
      variant_id: sanitizeString(item.variant_id),
      qty: sanitizeNumber(item.qty) || 1,
      unit_price: sanitizeNumber(item.unit_price),
      original_price: sanitizeNumber(item.original_price),
      commission: sanitizeNumber(item.commission),
    }));

    for (const item of normalizedItems) {
      if (!isValidObjectId(item.product_id)) {
        return res.status(400).json({ success: false, message: "Invalid product_id" });
      }
      if (item.variant_id && !isValidObjectId(item.variant_id)) {
        return res.status(400).json({ success: false, message: "Invalid variant_id" });
      }
      if (item.qty <= 0) {
        return res.status(400).json({ success: false, message: "Invalid qty" });
      }
    }

    const cart = await Cart.findOneAndUpdate(
      { user_id: req.user },
      { items: normalizedItems },
      { upsert: true, new: true }
    );
    res.status(200).json({ success: true, data: cart });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.addItem = async (req, res) => {
  try {
    const item = req.body;
    const productId = sanitizeString(item.product_id);
    const variantId = sanitizeString(item.variant_id);
    if (!productId || !isValidObjectId(productId)) {
      return res.status(400).json({ success: false, message: "product_id is required" });
    }
    if (variantId && !isValidObjectId(variantId)) {
      return res.status(400).json({ success: false, message: "Invalid variant_id" });
    }
    const qty = sanitizeNumber(item.qty) || 1;
    if (qty <= 0) {
      return res.status(400).json({ success: false, message: "Invalid qty" });
    }

    const update = {
      $push: {
        items: {
          product_id: productId,
          variant_id: variantId,
          qty,
          unit_price: sanitizeNumber(item.unit_price),
          original_price: sanitizeNumber(item.original_price),
          commission: sanitizeNumber(item.commission),
        },
      },
    };

    const cart = await Cart.findOneAndUpdate(
      { user_id: req.user },
      update,
      { upsert: true, new: true }
    );
    res.status(200).json({ success: true, data: cart });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.removeItem = async (req, res) => {
  try {
    const { itemIndex } = req.params;
    const cart = await Cart.findOne({ user_id: req.user });
    if (!cart) {
      return res.status(404).json({ success: false, message: "Cart not found" });
    }
    const index = Number(itemIndex);
    if (Number.isNaN(index) || index < 0 || index >= cart.items.length) {
      return res.status(400).json({ success: false, message: "Invalid item index" });
    }
    cart.items.splice(index, 1);
    await cart.save();
    res.status(200).json({ success: true, data: cart });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.clearCart = async (req, res) => {
  try {
    const cart = await Cart.findOneAndUpdate(
      { user_id: req.user },
      { items: [] },
      { new: true }
    );
    res.status(200).json({ success: true, data: cart || { user_id: req.user, items: [] } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
